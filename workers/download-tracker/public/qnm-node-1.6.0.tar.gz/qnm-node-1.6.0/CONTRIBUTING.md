# Contributing to qnm-node

**Forks are first-class.** Apache-2.0. You do not need permission to
fork, patch, or redistribute.

**Forks are welcome and always allowed.**

## How to run tests

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
python -m pytest -q
```

Python 3.10+. Core is stdlib only. pytest is the dev extra. No network.

## Ground rules (QNM-BUILD-1.0 + AIH-WP-1.3 + QNS-CD-1.0)

1. **Identity is Aziel Eliab only.**
2. Radios stay off until fabric enable; then the software path is ON.
   OS PHYs (cellular/mmcli, Wi-Fi/NM, BlueZ, gpsd, libnfc/PCSC) stamp
   LIVE | ABSENT | REFUSED — never mock chatter. Radio LIVE only on
   adapter presence. Local API binds 127.0.0.1 only. qnm is the one
   local door. GET /v1/mesh never enables. Token / shelf key never in
   git. Plaintext tip export off-loopback refuses.
3. Receipts go to disk. Chain is append-only.
4. Poison is refused, not interpreted (APG).
5. Tamper isolates. No auto-heal.
6. PHOENIX-LOCK waits / re-seals locally after poison or isolation.
   No controller hunt. Not public hostname restore. Public tunnels
   and sites die with the pull.
7. Tethers drop clean. No auto-rewire.
8. No account resurrection.
9. AnonBroadcast is never a publish path.
10. No Lumen / Mandible live symbols. No `lattice_online` / `mesh_complete`.
11. Score never reads views.
12. Pair-id is medium-independent (AIH-WP-1.3). Bearer is hop-only.
    Isolation / PHOENIX-LOCK / Scorch / operator cut edges. Wi-Fi death
    does not. Not Bell-pair physics. No qubit claims.
13. New behavior needs a §14 (or AIH-WP-1.3 / QNS-CD-1.0) test that
    fails without the change.
14. Local `qnsd` owns vias. Sticky-via banned. API 127.0.0.1 only.
    Photon id does not change across hops. Anon-broadcast never publishes.
15. Split the wires. Cold copies. Re-expand from archive bytes. Reheal
    from own last good tip or phoenix-WAIT. Cross-network survival:
    public network is not required to preserve tips.
16. No lie. No rewrite. Receipts still hash. Verify without voice.
    Copies not all on one tunnel. Network never lies to stay alive,
    adapt, or prevent death. There is no rewrite key.
17. Fabric pipeline stays local. Do not add a call-AZ-Generator path.
    Node Gate is MirageGrid only (outward claim stranger). Fabric
    enable allows software paths. Cellular / Wi-Fi / BT / GNSS / NFC
    are LIVE OS bindings or ABSENT/REFUSED — no MOCK chatter.
    GET /v1/mesh never enables radios. Plane B does not require a
    Zenodo DOI; hash-verified Codeberg / archive.org / GitFlic shelves
    count. Plane C USB airgap needs operator offline-verify/attest
    before fielded LIVE. Public receipts stay no user/geo. No public
    hostname restore. No public qnsd proxy. Via payloads
    sanitize-refuse. No hub chrome.

## License of contributions

By submitting a change you agree it is licensed under Apache-2.0.
Author: Aziel Eliab only.
