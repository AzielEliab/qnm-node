# QNM-BUILD-1.0 — Quantum Node Mesh Build Guide

**Author:** Aziel Eliab only
**Companion:** AIH-WP-1.3 (Spiderweb Pair-Bind; medium-independent)
**Hub / Interface law:** AIH-WP-1.1 (AZHub / AZInterface remain separate)
**License:** Apache-2.0
**Date:** September 2026
**Software:** qnm-node 1.1.0

This document is the law for the local node process. Public identity is
**Aziel Eliab** only.

## §1 Identity

Aziel Eliab only. No other author name. No account object. A node is an
`install_root`, not a login.

## §2 Bulletproof law

- Local modules run with **radios off**.
- Receipts go to **disk**.
- Poison is **refused, not interpreted**.
- Tamper **isolates**.
- **PHOENIX-LOCK** waits / re-seals locally after poison or isolation.
  No controller hunt. **Not** public hostname restore.
- Tethers **drop clean**.
- **No account resurrection**.
- AnonBroadcast is **never a publish path**.
- No **Lumen** / **Mandible** live symbols.
- No **lattice_online** / **mesh_complete**.
- **Score never reads views**.
- **Split the wires:** tick plane is presence + tip hash only (0.5–1s,
  fixed-size). Payload plane is pull-only. 1s loop and 777s gate never
  share a socket.
- **Cold copies** survive a public pull. No live body sync. Named hosts
  only; no unmarked hydra; no VPN concealment.
- **Re-expand** is archive verify + a new local node on tip. Bytes, not
  summaries. Crawlers do not re-expand. Weights are not the tarball.
- **Reheal** is own last good tip + trusted pull, or phoenix-WAIT. Not
  neighbor chatter. No majority fanfic.
- **Cross-network survival:** if the public network and live data die,
  the chain still survives. Local verify / append stay offline. The
  mesh does not need the public network to preserve tips.
- **No lie:** the network never lies, even to stay alive, adapt, or
  prevent death. Receipts still hash. Verify is without voice.
- **No rewrite:** there is no rewrite key. A published tip cannot be
  rewritten or mutated. Copies are not all on one tunnel.

## §3 Tree

```
qnm/{boot,node,chain,apg,bearers,outbox,phoenix,score,memorial,tethers,pairs,spiderweb,wires,coldcopy,archive,nolie}.py
modules/anon-broadcast/          loopback-only
cfg/node.json
data/{chain,locks,outbox,receipts,witness,vault,archive}
docs/{QNM-BUILD-1.0,AIH-WP-1.3,SPLIT-WIRES-1.0,COLD-COPY-1.0,RE-EXPAND-1.0,REHEAL-1.0,CROSS-NETWORK-SURVIVAL-1.0,NO-LIE-1.0,NO-REWRITE-1.0}.md
tests/                           §14 + AIH-WP-1.3 + wires + cold-copy + archive + reheal + survival + nolie
```

## §4 Boot

```
install_root = SHA256(entropy || nonce || optional_genesis)
```

Two installs produce two roots. Resume is allowed **only** from
`data/locks/`. A scorched lock cannot return to LOCAL or LIVE.

## §5 State

```
COLD → LOCAL → LIVE(operator bearer) → DEGRADED → ISOLATED → PHOENIX_LOCK → SCORCHED
```

Forward-only. **No auto-heal.** **No LIVE from site ping.**
**PHOENIX-LOCK** is wait / re-seal — not restore of a public hostname,
`.uk`, tunnel, or Worker rollup. Public tunnels and sites **die with
the pull**. Local API binds **127.0.0.1** only:

`/local/boot` `/local/state` `/local/bearer` `/local/tether`
`/local/pair` `/local/pairs` `/local/forward`
`/local/ingress` `/local/outbox` `/local/outbox/cut`
`/local/phoenix/arm` `/local/receipts`
`/local/tick` `/local/pull` `/local/cite` `/local/emit`
`/local/rejoin` `/local/vault` `/local/wires`
`/local/archive` `/local/reheal` `/local/survive`
`/local/nolie` `/local/rewrite`

## §6 Bearers

`local` is on. `operator`, `lan`, `radio`, `remote` default off. Radio
and remote cannot be enabled. LIVE requires an explicit operator bearer.

## §7 APG

Every ingress is scanned as raw bytes. Matching a poison marker refuses
the payload without interpreting it.

## §8 Chain and receipts

Append-only JSONL under `data/chain/`. One receipt file per event under
`data/receipts/`. No rewrite.

## §9 Outbox

Visible local queue. Cut drops the item. `publish` is refused.

## §10 Tethers

Declared corridors only (AIH-WP-1.1). Cut leaves no residue and does
not auto-rewire. Stored under `data/witness/`. Pair-bind edges are
**AIH-WP-1.3** (medium-independent spiderweb) — not these tethers.
See [AIH-WP-1.3.md](AIH-WP-1.3.md).

## §11 PHOENIX-LOCK

Operator arm. Wait / re-seal after poison or isolation. The node waits
on this machine. `hunt_controller` is refused (`QNM-PHOENIX-LOCAL-WAIT`).

Phoenix does **not** restore a public hostname, `.uk`, Cloudflare
tunnel, Worker, or public rollup. It is not “bring the public node
back.” Public tunnels and sites **die with the pull**: a Cloudflare
Tunnel lives on token + DNS name + account; pull site / revoke token /
drop Worker / kill DNS → `cloudflared` has nowhere legal to land.
Restarting `cloudflared` is operator kit, not this contract, and fails
if credential or hostname is gone. After a pull, public rollup is
down. The local node may keep verifying and appending. Mesh does not
climb back onto the public hostname by itself. No controller hunt.

## §12 Score (QNM-S)

Local chain integrity and posture only. Views, downloads, and ranking
are refused.

## §13 Memorial / no resurrection

SCORCHED writes `data/witness/memorial.json`, marks the lock scorched,
clears tethers and outbox. `account_resurrect` / `account_restore` /
`account_create` refuse (`QNM-NO-ACCOUNT`).

## §14 Tests (ship these)

| File | Law |
|------|-----|
| `tests/test_offline.py` | Radios off; two roots; resume locks only; no LIVE from ping; no auto-heal; receipts on disk; 127.0.0.1 API |
| `tests/test_apg.py` | Every ingress through APG; poison refused not interpreted |
| `tests/test_tamper.py` | Tamper isolates; no auto-heal out of ISOLATED |
| `tests/test_phoenix.py` | PHOENIX-LOCK waits / re-seals locally; no controller hunt; not public hostname restore; reheal waits when trust is gone |
| `tests/test_tether.py` | Tethers drop clean; isolate drops tethers; no neighbor rewire |
| `tests/test_no_account.py` | No account resurrection; identity Aziel Eliab; score ignores views; anon-broadcast never publishes |
| `tests/test_spiderweb.py` | AIH-WP-1.3: pair survives bearer off; forward along spiderweb with APG; isolated node has no edges; hop_max / loop drop |
| `tests/test_wires.py` | SPLIT-WIRES-1.0: tick plane; pull-only payload; cite/dwell/equivocation/partition |
| `tests/test_coldcopy.py` | COLD-COPY-1.0: N replicas survive pull; no live sync; named hosts only |
| `tests/test_archive.py` | RE-EXPAND-1.0: chain bytes, not summaries; new node on tip; no crawler / index / weights |
| `tests/test_reheal.py` | REHEAL-1.0: own last good + trusted pull; no neighbor / majority; chatter is status+tip-hash |
| `tests/test_survival.py` | CROSS-NETWORK-SURVIVAL-1.0: offline verify/append after public death; refuse network-required |
| `tests/test_nolie.py` | NO-LIE-1.0 / NO-REWRITE-1.0: receipts still hash; verify without voice; no rewrite key; published tip immutable; no one-tunnel; no lie-to-live heal |

## §15 Split the wires

Two planes. They never share a socket.

Tick (0.5–1s): presence + tip hash only. Fixed-size. No body, no diff,
no file. Payload: the receiver **pulls**. Update is a proof (cite prev +
lockset, fail-closed). 777s is dwell after a valid cite — not a timer
that accepts whatever arrived. Clock desync is not a yes. Ambiguous tip
isolates. Equivocation locks that peer; the chain continues. Emit only
after own verify. No unsend. No auto-splice. Heartbeat loss is not
poison and is not apply-last-packet. See [SPLIT-WIRES-1.0](SPLIT-WIRES-1.0.md).

## §16 Cold-copy survival

N named cold replicas (MESH-VAULT on transfer, reader local vaults,
optional pin of already-public tip/receipt hashes). Pulling origin /
Worker / DNS **dies with the pull** and does not erase cold copies.
Local verify / append continues. No live body sync. Named hosts only.
No unmarked hydra. No VPN concealment. See
[COLD-COPY-1.0](COLD-COPY-1.0.md).

## §17 Re-expand from archive

Bytes of the chain survive, not summaries. Re-expand verifies the
tarball and seats a **new** local node on that tip. It is not mesh
growing from an index. Crawlers do not re-expand. Weights are not the
tarball. See [RE-EXPAND-1.0](RE-EXPAND-1.0.md).

## §18 Reheal

A poisoned node heals from its own last good tip plus a verified pull
of bytes it already trusted — or it phoenix-WAITs. It does not heal by
listening to neighbors. Allowed chatter: live / locked / isolated /
tip-hash. Isolate drops tethers; other nodes keep their chain. No
majority fanfic. See [REHEAL-1.0](REHEAL-1.0.md).

## §19 Cross-network survival

If the public network and live data die tomorrow, the chain still
survives via cold copies, archive re-expand, and self-reheal. The local
node keeps verifying and appending offline. The mesh does not need the
public network to preserve tips. `require_public_network` and
`require_live_data` refuse (`QNM-SURVIVE-OFFLINE`). See
[CROSS-NETWORK-SURVIVAL-1.0](CROSS-NETWORK-SURVIVAL-1.0.md).

## §20 No lie / no rewrite

The network never lies — not to a peer, not to itself, not to stay
alive, adapt, or prevent death. Receipts still hash. Verify is
hash-only (no voice). There is no rewrite key. A published tip cannot
be rewritten or mutated (`QNM-NO-REWRITE`). Copies are not all on one
tunnel (`QNM-NO-ONE-TUNNEL`). Lie-to-live heal paths refuse
(`QNM-NO-LIE-TO-LIVE`). See [NO-LIE-1.0](NO-LIE-1.0.md) and
[NO-REWRITE-1.0](NO-REWRITE-1.0.md).

## Cite

Eliab, Aziel. (2026). QNM-BUILD-1.0 Quantum Node Mesh local node
[Software]. Apache-2.0. https://github.com/AzielEliab/qnm-node

Eliab, Aziel. (2026). AIH-WP-1.3 Spiderweb Pair-Bind [Law].
Companion: QNM-BUILD-1.0. Apache-2.0.
https://github.com/AzielEliab/qnm-node

Eliab, Aziel. (2026). SPLIT-WIRES-1.0 / COLD-COPY-1.0 / RE-EXPAND-1.0 /
REHEAL-1.0 / NO-LIE-1.0 / NO-REWRITE-1.0 mesh law [Law]. Companion:
QNM-BUILD-1.0. Apache-2.0. https://github.com/AzielEliab/qnm-node

Do not invent a DOI.

Apache-2.0. Forks are welcome and always allowed.
