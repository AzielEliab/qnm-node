# Fabric design papers

Author: **Aziel Eliab** only.

Companion to `QNM-BUILD-1.0.md` and `AIH-WP-1.3.md`.

| Paper | One line |
| --- | --- |
| [QNM-WP-1.0](./QNM-WP-1.0.md) | Quantum Node Mesh — local ON / public rollup dies with pull; cell 25 + 2 bridges |
| [NODE-OPS-1.0](./NODE-OPS-1.0.md) | Node operations + surface law + phoenix wait / re-seal (not public hostname restore) |
| [QNS-CD-1.0](./QNS-CD-1.0.md) | Quantum Node Signal Coding Design — local `qnsd` owns vias; photon packet |
| [SPLIT-WIRES-1.0](./SPLIT-WIRES-1.0.md) | Tick plane = presence + tip hash; payload is pull-only; two clocks stay strangers |
| [COLD-COPY-1.0](./COLD-COPY-1.0.md) | N named cold replicas; no live body sync; public pull does not erase copies |
| [RE-EXPAND-1.0](./RE-EXPAND-1.0.md) | Archive bytes, not summaries; verify + new local node on tip |
| [REHEAL-1.0](./REHEAL-1.0.md) | Own last good tip + trusted pull, or phoenix-WAIT; no neighbor / majority reheal |
| [CROSS-NETWORK-SURVIVAL-1.0](./CROSS-NETWORK-SURVIVAL-1.0.md) | If network + live data die, chain survives (cold copy / re-expand / self-reheal) |
| [NO-LIE-1.0](./NO-LIE-1.0.md) | Network never lies, even to stay alive / adapt / prevent death; receipts still hash; verify without voice |
| [NO-REWRITE-1.0](./NO-REWRITE-1.0.md) | No rewrite key; published tip immutable; copies not all on one tunnel |
| [FABRIC-MESH-PIPELINE-1.0](./FABRIC-MESH-PIPELINE-1.0.md) | Local ingress → APG → stranger clocks → via walker → photon → outbox → survival; ALL-CHANNELS-ON; OS radios LIVE\|ABSENT\|REFUSED (supersedes MOCK stamps); hash-verified Codeberg/archive/GitFlic shelves (Zenodo not required); unkillability architecture ≠ fielded (hubs must not publish 100); MirageGrid Node Gate is an external claim stranger |
| [RADIO-PHY-1.0](./RADIO-PHY-1.0.md) | Cellular ModemManager, Wi-Fi+BT NM/BlueZ, GNSS gpsd, NFC libnfc/PCSC — LIVE\|ABSENT\|REFUSED; no mock chatter |
| [ATTACK-SURFACE-1.0](./ATTACK-SURFACE-1.0.md) | Listen map; qnm is THE local door; WAN refused; qnsd HTTP is extra-door |
| [REDLINE-1.0](./REDLINE-1.0.md) | Auth / token-never-in-git / mesh GET never enables / AZ Generator not callable / radio LIVE only on presence / poison refuse / no rewrite |
| [FED-MESH-1.0](./FED-MESH-1.0.md) | Local-first edge mesh on this daemon: per-handle keys, ciphertext shares, cluster-before-relay, content-addressed refs. Draft wire; not a claim that the runtime Worker speaks it |

QNM-WP-1.0 absorbs BUILD+TOPO: local process ON, public rollup OFF and
dies with the pull; GET /v1/mesh never enables. Phoenix is wait /
re-seal after poison or isolation — not restore of a public hostname.

QNS-CD-1.0 is the coding design for the local `qnsd` process (parents:
QNS-WP-1.3 · QNM-BUILD-1.0 · AIH-WP-1.3 · APG · AZPIPE · ChainLock).
Local qnsd owns vias. Suite Workers cite/proxy only. Not a
Softwares-tab product. GET /v1/mesh never enables. No Node Gate
in qnm-node. Node Gate is a MirageGrid subsystem only (outward claim
surface; AZ Generator is not called from this repo).
Print companion: `QNS-CD-1.0.pdf` (git-hosted; Worker does not serve).

FABRIC-MESH-PIPELINE-1.0 locks the local order (APG → wires → vias →
photon → outbox → phoenix / reheal / cold-copy). MirageGrid claim
clock is an external stranger to qnm tip and dwell clocks. When
fabric-enabled, RF / BT / Wi-Fi / photon software paths may be ON.
Cellular / Wi-Fi / BT / GNSS / NFC stamp **LIVE | ABSENT | REFUSED**
from real OS probes. Camera/emitter stays HOOK-PENDING. Public
receipts stay no user/geo. Plane C USB airgap requires operator
offline-verify/attest before LIVE.
