"""Internal bitmesh geo plane — FABRIC-MESH-PIPELINE-1.0.

Geohash (or equivalent) binds to a tip for **internal bitmesh routing
only**. This is not public ACT-RECEIPT geo and not a fielded radio.
Bitmesh geo binds only from a LIVE GNSS fix (`RADIO-NO-GNSS`
without a receiver). Public receipts stay no user / no geo / no IP.

Author: Aziel Eliab only.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from qnm.boot import AUTHOR, SPEC, QNMRefuse, _utc_now, sha256_hex

BITMESH_SPEC = "BITMESH-GEO-1.0"
BITMESH_PLANE = "bitmesh-internal"
GEOHASH_BASE32 = "0123456789bcdefghjkmnpqrstuvwxyz"

PUBLIC_GEO_KEYS = frozenset(
    {
        "geo",
        "geohash",
        "lat",
        "lon",
        "latitude",
        "longitude",
        "location",
        "user",
        "user_id",
        "userid",
        "ip",
        "client_ip",
    }
)


def geohash(lat: float, lon: float, *, precision: int = 8) -> str:
    """Encode a WGS-84 point. Internal routing token only."""
    if lat < -90.0 or lat > 90.0 or lon < -180.0 or lon > 180.0:
        raise QNMRefuse("QNM-BITMESH-GEO", "lat/lon out of range")
    precision = max(1, min(int(precision), 12))
    lat_range = [-90.0, 90.0]
    lon_range = [-180.0, 180.0]
    bits: list[int] = []
    lon_bit = True
    while len(bits) < precision * 5:
        if lon_bit:
            mid = (lon_range[0] + lon_range[1]) / 2.0
            if lon >= mid:
                bits.append(1)
                lon_range[0] = mid
            else:
                bits.append(0)
                lon_range[1] = mid
        else:
            mid = (lat_range[0] + lat_range[1]) / 2.0
            if lat >= mid:
                bits.append(1)
                lat_range[0] = mid
            else:
                bits.append(0)
                lat_range[1] = mid
        lon_bit = not lon_bit
    chars: list[str] = []
    for index in range(0, len(bits), 5):
        value = 0
        for bit in bits[index : index + 5]:
            value = (value << 1) | bit
        chars.append(GEOHASH_BASE32[value])
    return "".join(chars)


def public_receipt_has_geo(payload: dict[str, Any] | None) -> bool:
    """True when a public-facing mapping carries user/geo/IP keys."""
    return bool(_geo_keys_in(payload or {}))


def _geo_keys_in(obj: Any) -> set[str]:
    found: set[str] = set()
    if isinstance(obj, dict):
        for key, value in obj.items():
            lowered = str(key).lower()
            if lowered in PUBLIC_GEO_KEYS:
                found.add(lowered)
            found |= _geo_keys_in(value)
    elif isinstance(obj, (list, tuple)):
        for item in obj:
            found |= _geo_keys_in(item)
    return found


def refuse_public_geo(payload: dict[str, Any] | None) -> dict[str, Any]:
    """Public receipts stay no user / geo. Refuse; do not rewrite."""
    body = dict(payload or {})
    if public_receipt_has_geo(body):
        raise QNMRefuse(
            "QNM-NO-PUBLIC-GEO",
            "public receipts stay no user/geo; bitmesh geo is internal only",
        )
    return body


class Bitmesh:
    """Internal geohash binds. Never a public ACT-RECEIPT field."""

    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.dir = self.root / "data" / "bitmesh"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.path = self.dir / "binds.jsonl"
        if not self.path.is_file():
            self.path.write_text("", encoding="utf-8")

    def status(self, *, phy_runner: Any = None) -> dict[str, Any]:
        from qnsd.phy import probe

        card = probe("gps", runner=phy_runner)
        live = bool(card.get("live"))
        binds = len(self.list())
        if live:
            fielding = "LIVE"
        elif binds:
            fielding = "ABSENT"
        else:
            fielding = "ABSENT"
        return {
            "ok": True,
            "spec": BITMESH_SPEC,
            "build": SPEC,
            "author": AUTHOR,
            "plane": BITMESH_PLANE,
            "channel": fielding,
            "fielded": False,
            "public": False,
            "public_receipt_geo": False,
            "binds": binds,
            "gps_driver": live,
            "default_off": not live,
            "fielding": fielding,
            "live_fix": live,
        }

    def list(self) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                items.append(json.loads(line))
        return items

    def bind(
        self,
        tip: str,
        *,
        lat: float | None = None,
        lon: float | None = None,
        precision: int = 8,
        public: bool = False,
        phy_runner: Any = None,
    ) -> dict[str, Any]:
        """Bind a geohash from a LIVE GNSS fix. Never invent a position."""
        if public:
            raise QNMRefuse(
                "QNM-NO-PUBLIC-GEO",
                "bitmesh geo is not a public ACT-RECEIPT field",
            )
        from qnsd.phy import probe

        card = probe("gps", runner=phy_runner)
        if not card.get("live"):
            raise QNMRefuse(
                "RADIO-NO-GNSS",
                "bitmesh geo needs a LIVE GNSS receiver; no invented fix",
            )
        fix = dict(card.get("fix") or {})
        use_lat = fix.get("lat") if fix.get("lat") is not None else lat
        use_lon = fix.get("lon") if fix.get("lon") is not None else lon
        if use_lat is None or use_lon is None:
            raise QNMRefuse(
                "RADIO-NO-GNSS",
                "GNSS LIVE but no 2D/3D fix; refuse invented coordinates",
            )
        digest = str(tip or "").strip().lower()
        if len(digest) != 64:
            raise QNMRefuse("QNM-WIRES-FAIL-CLOSED", "bitmesh bind needs a tip hash")
        token = geohash(float(use_lat), float(use_lon), precision=precision)
        rec = {
            "tip": digest,
            "geohash": token,
            "precision": int(precision),
            "plane": BITMESH_PLANE,
            "public": False,
            "public_receipt": False,
            "act_receipt_geo": False,
            "gps_driver": True,
            "fielding": "LIVE",
            "default_off": False,
            "utc": _utc_now(),
            "spec": BITMESH_SPEC,
            "author": AUTHOR,
            "bind_id": sha256_hex(f"{digest}:{token}".encode("utf-8")),
        }
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(rec, sort_keys=True, separators=(",", ":")) + "\n")
            fh.flush()
        return rec

    def for_tip(self, tip: str) -> list[dict[str, Any]]:
        digest = str(tip or "").strip().lower()
        return [row for row in self.list() if row.get("tip") == digest]

    def route_token(self, tip: str) -> str | None:
        rows = self.for_tip(tip)
        if not rows:
            return None
        return str(rows[-1].get("geohash") or "") or None
